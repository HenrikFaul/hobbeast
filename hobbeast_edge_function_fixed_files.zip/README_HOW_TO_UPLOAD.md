# Hobbeast Edge Function fixed files

These files are ready-to-upload replacements for the repo.

## Files included
- `supabase/functions/delete-account/index.ts`
- `supabase/functions/eventbrite-import/index.ts`
- `supabase/functions/mapy-routing/index.ts`
- `supabase/functions/mass-create-users/index.ts`
- `supabase/functions/place-search/index.ts`
- `supabase/functions/seed-venues/index.ts`
- `supabase/functions/shared/providerFetch.ts`
- `supabase/functions/sync-external-events/index.ts`

## What was fixed
- Added missing CORS headers for browser-invoked Edge Functions:
  - `Access-Control-Allow-Methods`
  - `Access-Control-Max-Age`
- Fixed `mass-create-users` gender normalization so Hungarian values like `Férfi` and `Nő`
  are mapped to DB-safe values such as `male` and `female`.

## Simplest GitHub web workflow
1. Open your repo on GitHub.
2. Navigate to each matching file path.
3. Click the file, then use the pencil/Edit button.
4. Replace the existing file content with the content from the matching file in this package.
5. Commit the change directly to your branch.
6. Repeat for all 8 files.

## Better workflow in Codespaces / local repo
1. Extract this package.
2. Copy the included `supabase` folder on top of your repo root and allow overwrite.
3. Run:
   - `git status`
   - `git diff`
   - `git add supabase/functions`
   - `git commit -m "Fix Edge Function CORS and mass-create-users normalization"`
   - `git push`

## After code is in GitHub
Redeploy the affected Supabase Edge Functions.
