import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
  'Access-Control-Max-Age': '86400',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const apiKey = Deno.env.get('MAPY_CZ_API_KEY');
  if (!apiKey) {
    return new Response(JSON.stringify({ error: 'MAPY_CZ_API_KEY not configured' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  try {
    const { action, params } = await req.json() as {
      action: 'route' | 'elevation';
      params: Record<string, unknown>;
    };

    if (action === 'route') {
      const { start, end, waypoints = [], routeType = 'foot_fast' } = params as {
        start: { lat: number; lon: number };
        end: { lat: number; lon: number };
        waypoints?: { lat: number; lon: number }[];
        routeType?: string;
      };

      let url = `https://api.mapy.cz/v1/routing/route?apikey=${apiKey}` +
        `&start=${start.lon},${start.lat}` +
        `&end=${end.lon},${end.lat}` +
        `&routeType=${routeType}` +
        `&format=geojson` +
        `&lang=cs`;

      if (waypoints.length > 0) {
        const wp = waypoints.map(w => `${w.lon},${w.lat}`).join('|');
        url += `&waypoints=${wp}`;
      }

      const res = await fetch(url);
      if (!res.ok) {
        const body = await res.text();
        throw new Error(`Mapy.cz routing error ${res.status}: ${body}`);
      }
      const data = await res.json();

      return new Response(JSON.stringify(data), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (action === 'elevation') {
      const { coordinates } = params as {
        coordinates: [number, number][]; // [lon, lat][]
      };

      // Mapy.cz elevation API: POST with coordinates
      const url = `https://api.mapy.cz/v1/elevation?apikey=${apiKey}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          coordinates: coordinates.map(([lon, lat]) => ({ lon, lat })),
        }),
      });

      if (!res.ok) {
        const body = await res.text();
        throw new Error(`Mapy.cz elevation error ${res.status}: ${body}`);
      }
      const data = await res.json();

      return new Response(JSON.stringify(data), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ error: 'Unknown action. Use "route" or "elevation".' }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('mapy-routing error:', error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
